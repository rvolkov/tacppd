# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/includegraphics[bb=00200100,draft,type=eps]{tacppd.org.jpg};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="320" HEIGHT="160" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[bb = 0 0 200 100, draft, type=eps]{tacppd.org.jpg}">|; 

1;

